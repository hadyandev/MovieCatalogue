package com.hadyandev.moviecatalogue.adapter;

import com.hadyandev.moviecatalogue.model.Movie;

public interface MovieClickListener {
    void onMovieClicked(Movie movie);
}
